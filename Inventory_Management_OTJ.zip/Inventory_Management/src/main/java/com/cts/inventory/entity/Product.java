package com.cts.inventory.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;				//REPRESENTS UNIQUE ID FOR A PRODUCTS
	
	private String productName;		//REPRESENTS NAME OF A PRODUCT
	private String description;		//REPRESENTS SHORT DESCRIPTION OF A PRODUCT
	private float price;			//REPRESENTS PRICE OF A PRODUCT
	private long quantity;			//REPRESENTS QUANTITY AVAILABLE FOR A PRODUCT
	
	@CreationTimestamp
	private Date createdDate;		//REPRESENTS A DATE IN WHICH PRODUCT WAS CREATED

	@UpdateTimestamp
	private Date updatedDate;		//REPRESENTS A DATE IN WHICH PRODUCT WAS LAST MODIFIED

	public Product() {
		super();
	}

	public Product(String productName, String description, float price, long quantity) {
		super();
		this.productName = productName;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

}
