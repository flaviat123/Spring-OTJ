package com.cts.inventory.config;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cts.inventory.entity.Product;
import com.cts.inventory.service.ProductServiceImpl;

@Component
public class DataLoaderOnStartUp implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(DataLoaderOnStartUp.class);

	private ProductServiceImpl prodServiceImpl;

	@Autowired
	public DataLoaderOnStartUp(ProductServiceImpl inventoryServiceImpl) {
		this.prodServiceImpl = inventoryServiceImpl;
	}

	@Override
	public void run(String... args) throws Exception {
		List<Product> products = Arrays.asList(new Product("MOISTURIZER", "ALL SKIN TYPES-50GM", 200, 10),
				new Product("TONER", "ALL SKIN TYPES-250ML", 250, 10),
				new Product("FACE MIST", "ALL SKIN TYPES-250ML", 250, 15),
				new Product("BODY BUTTER", "ALL SKIN TYPES-100GM", 450, 20),
				new Product("LIP BALM", "ALL SKIN TYPES-4GM", 150, 25));
		prodServiceImpl.saveAllProducts(products);
	}

}