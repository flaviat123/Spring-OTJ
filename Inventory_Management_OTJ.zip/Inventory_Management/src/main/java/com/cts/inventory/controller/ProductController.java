package com.cts.inventory.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.inventory.entity.Product;
import com.cts.inventory.exception.ResourceNotFoundException;
import com.cts.inventory.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;

	/*****		TO GET ALL THE PRODUCTS		*****/	
	@GetMapping("/products")
	public List<Product> getAllProduct(){
		return productService.getAllProduct();
	}
	
	/*****		TO GET THE PRODUCT FOR A PARTICULAR ID		*****/
	@GetMapping("/products/{id}")
	public Product getProductById(@PathVariable long id){
		return productService.getProductById(id);
	}
	
	/*****		REQUIREMENT-4 (TO RETURN SPECIFIC HTTP CODE TO RETAILER FOR PROMOTION)	*****/
	@GetMapping("/retail/{id}")
	public Product getProductForRetail(HttpServletResponse response,@PathVariable long id){
		if(id==1){
			response.setStatus(302);
			throw new ResourceNotFoundException("SORRY!! THE PRODUCT WITH ID '1' IS MOVED TEMPORARILY");
		}
		else{
			response.setStatus(200);
			return productService.getProductById(id);
		}
	}
	
	/*****		TO GET THE PRICE OF A PARTICULAR PRODUCT		*****/
	@GetMapping("/price/{id}")
	@Cacheable("price")
	public double getPriceById(@PathVariable long id){
		return productService.getPriceById(id);
	}

	/*****		TO CREATE/ADD NEW PRODUCT		*****/
	@PostMapping("/products")
	public Product createProduct(@RequestBody Product product){
		return productService.createProduct(product);
	}

	/*****		TO UPDATE ALL THE FIELDS OF A PARTICULAR PRODUCT		*****/
	@PutMapping("/products/{id}")
	public Product updateProduct(@PathVariable long id, @RequestBody Product product){
		product.setId(id);
		return productService.updateProduct(product);
	}
	
	/*****		TO UPDATE ALL THE PRICE OF A PARTICULAR PRODUCT		*****/
	@PutMapping("/products/{id}/price/{price}")
	public Product updatePrice(@PathVariable long id,@PathVariable float price){
		return productService.updatePrice(id, price);
	}
	
	/*****		TO DELETE A PARTICULAR PRODUCT		*****/
	@DeleteMapping("/products/{id}")
	public HttpStatus deleteProduct(@PathVariable long id){
		this.productService.deleteProduct(id);
		return HttpStatus.OK;
	}

}
