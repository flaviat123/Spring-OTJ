package com.cts.inventory.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.inventory.exception.ResourceNotFoundException;


@ControllerAdvice
public class ExceptionController {
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public String handleException(ResourceNotFoundException ex) {
        return ex.getMessage();
    }
}