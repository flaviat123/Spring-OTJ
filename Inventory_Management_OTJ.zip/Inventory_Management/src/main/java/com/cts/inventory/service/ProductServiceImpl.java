package com.cts.inventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cts.inventory.entity.Product;
import com.cts.inventory.exception.ResourceNotFoundException;
import com.cts.inventory.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Value("${PRODUCT}")
	private List<String> bannedProd;

	@Override
	public Product createProduct(Product product) {
		if(!bannedProd.contains(product.getProductName().toUpperCase())){
		productRepository.save(product);
		}
		else {
			throw new ResourceNotFoundException("SORRY! THE PRODUCT '"+product.getProductName()+"' IS BANNED");
		}
		return product;
	}

	@Override
	public Product updateProduct(Product product) {
		Optional<Product> productDb = this.productRepository.findById(product.getId());
		if(productDb.isPresent()) {
			Product productUpdate = productDb.get();
			productUpdate.setId(product.getId());
			productUpdate.setPrice(product.getPrice());;
			productUpdate.setDescription(product.getDescription());
			productUpdate.setQuantity(product.getQuantity());
			productRepository.save(productUpdate);
			return productUpdate;
		}else {
			throw new ResourceNotFoundException("RECORD NOT FOUND WITH ID : " + product.getId());	
		}
	}

	@Override
	public List<Product> getAllProduct() {
		return this.productRepository.findAll();
	}

	@Override
	public Product getProductById(long productId) {
		Optional<Product> productDb = this.productRepository.findById(productId);
		if(productDb.isPresent()) {
			return productDb.get();
		}else {
			throw new ResourceNotFoundException("RECORD NOT FOUND WITH ID : " + productId);
		}
	}

	@Override
	public void deleteProduct(long id) {
		Optional<Product> productDb = this.productRepository.findById(id);
		if(productDb.isPresent()) {
			this.productRepository.delete(productDb.get());
		}else {
			throw new ResourceNotFoundException("RECORD NOT FOUND WITH ID : " + id);
		}
		
	}

	@Override
	public float getPriceById(long productId) {
		Optional<Product> productDb = this.productRepository.findById(productId);
		if(productDb.isPresent()) {
			return productDb.get().getPrice();
		}else {
			throw new ResourceNotFoundException("RECORD NOT FOUND WITH ID : " + productId);
		}	
	}

	@Override
	public Product updatePrice(long productId, float price) {
		Optional<Product> productDb = this.productRepository.findById(productId);
		if(productDb.isPresent()) {
			Product productUpdate = productDb.get();
			productUpdate.setPrice(price);
			productRepository.save(productUpdate);
			return productUpdate;
		}else {
			throw new ResourceNotFoundException("RECORD NOT FOUND WITH ID : " + productId);	
		}
	}
	
	public void saveAllProducts(List<Product> productList) {
		productRepository.saveAll(productList);
	}

}
