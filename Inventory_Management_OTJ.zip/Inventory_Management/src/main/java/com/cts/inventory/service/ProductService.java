package com.cts.inventory.service;

import java.util.List;

import com.cts.inventory.entity.Product;

public interface ProductService {
	
	Product createProduct(Product product);

	Product updateProduct(Product product);
	
	Product updatePrice(long productId,float price);

	List<Product> getAllProduct();

	Product getProductById(long productId);

	void deleteProduct(long productId);

	float getPriceById(long productId);

}
