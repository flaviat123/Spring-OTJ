package com.cts.inventory;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.cts.inventory.entity.Product;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ProductControllerTest {
	
	@LocalServerPort
	int randomServerPort;
	
	@Test
	public void testgetAllProduct() throws URISyntaxException{
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/products";
		URI uri = new URI(baseUrl);
		ResponseEntity<Product[]> result = restTemplate.getForEntity(uri, Product[].class);
		Assert.assertEquals(200, result.getStatusCodeValue());		
	}
	
	@Test
	public void testgetProductById() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		int productId = 1;
		final String baseUrl = "http://localhost:" + randomServerPort + "/products/" + productId;
		URI uri = new URI(baseUrl);
		ResponseEntity<Product> result = restTemplate.getForEntity(uri, Product.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}
	
	@Test
	public void testgetPriceById() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		int productId = 1;
		final String baseUrl = "http://localhost:" + randomServerPort + "/price/" + productId;
		URI uri = new URI(baseUrl);
		ResponseEntity<Double> result = restTemplate.getForEntity(uri, Double.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}
	
	@Test
	public void testcreateProduct() throws URISyntaxException {
		Product product = new Product();
		product.setProductName("LOTION");
		product.setDescription("ALL SKIN TYPES - 100GM");
		product.setPrice(450);
		product.setQuantity(15);
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/products";
		URI uri = new URI(baseUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Product> request = new HttpEntity<>(product, headers);
		ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}
	
	@Test
	public void testupdateProduct() throws URISyntaxException {
		Product product = new Product();
		product.setDescription("ALL SKIN TYPES - 100GM");
		product.setPrice(450);
		product.setQuantity(15);
		int productId = 1;
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/products/" + productId;
		URI uri = new URI(baseUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Product> request = new HttpEntity<>(product, headers);
		ResponseEntity<Product> result = restTemplate.exchange(uri, HttpMethod.PUT, request, Product.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}
	
	@Test
	public void testupdatePrice() throws URISyntaxException {
		int productId = 1;
		double price = 25000.0;
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/products/" + productId + "/price/" + price;
		URI uri = new URI(baseUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Product> request = new HttpEntity<>(headers);
		ResponseEntity<Product> result = restTemplate.exchange(uri, HttpMethod.PUT, request, Product.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}
	
	@Test
	public void testdeleteProduct() throws URISyntaxException {
		int productId = 3;
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/products/" + productId;
		URI uri = new URI(baseUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Product> request = new HttpEntity<>(headers);
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.DELETE, request, String.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}




}
