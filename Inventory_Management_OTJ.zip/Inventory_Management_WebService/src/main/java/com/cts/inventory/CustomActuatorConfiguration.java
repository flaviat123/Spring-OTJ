package com.cts.inventory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cts.inventory.controller.CustomEndPoint;

@Configuration
public class CustomActuatorConfiguration {

	@Bean
	public CustomEndPoint customEndPoint() {
		return new CustomEndPoint();
	}
}