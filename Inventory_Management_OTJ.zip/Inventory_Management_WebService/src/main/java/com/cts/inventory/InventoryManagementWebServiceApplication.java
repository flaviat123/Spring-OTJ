package com.cts.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryManagementWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryManagementWebServiceApplication.class, args);
	}

}
