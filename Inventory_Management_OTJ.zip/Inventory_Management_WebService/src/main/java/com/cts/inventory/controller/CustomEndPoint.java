package com.cts.inventory.controller;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

@Endpoint(id = "custom")
public class CustomEndPoint implements HealthIndicator {
	private final String message_key = "REGULAR HEALTH CHECK SERVICE";

	@Override
	@ReadOperation
	public Health health() {
		if (!isRunningService()) {
			return Health.down().withDetail(message_key, "NOT AVAILABLE").build();
		}
		return Health.up().withDetail(message_key, "AVAILABLE").build();
	}

	private Boolean isRunningService() {
		Boolean isRunning = true;
		return isRunning;
	}
}
