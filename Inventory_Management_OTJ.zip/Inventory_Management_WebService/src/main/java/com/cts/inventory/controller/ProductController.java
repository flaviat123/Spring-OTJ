package com.cts.inventory.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.cts.inventory.Product;
import com.cts.inventory.service.ProductServiceImpl;

@Controller
public class ProductController {
	
	@Autowired
	ProductServiceImpl prodService;
	
	@GetMapping("/products")
	public String findAllProducts(Model model) {
		Product[] productList = prodService.getAllProduct();
		model.addAttribute("productList", productList);
		return "Product";
	}
	
	@GetMapping("/home")
	public String  home()
	{
		return "Home";		
	}

}
