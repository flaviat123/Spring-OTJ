package com.cts.inventory.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cts.inventory.Product;

@Service
public class ProductServiceImpl {
	
	@Value("${service.url}")
	private String serviceUrl;

	RestTemplate productRestTemplate = new RestTemplate();

	public Product[] getAllProduct() {
		Product[] productList = productRestTemplate.getForObject(serviceUrl + "/products", Product[].class);
		return productList;
	}

}
